import React, { useContext, useState } from 'react';
import { useFetch } from '../../hooks/useFetch';
import PokemonModal from './PokemonModal';
import PokemonFeatures from './PokemonFeatures';
import { capitalize, formatAbilities } from '../../utils/format';
import { LoginContext } from '../../context/LoginContext';

const PokemonCard = ({ pokemonUrl }) => {
  const { data, isLoading, error } = useFetch(pokemonUrl);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { userLoggedIn } = useContext(LoginContext);

  // TODO: zrobić komponenty Loader i Error
  if (isLoading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;
  if (!data) return null; // Na wypadek, gdyby data była nadal null

  //Nazwa z dużej litery - sprawdź czy jest inny sposób??
  //jeżeli będzie w innych komponentach to wyodrębnić -> utils? - chyba OK

  const pokemonData = {
    id: data.id,
    // name: data.name.charAt(0).toUpperCase() + data.name.slice(1),
    name: capitalize(data.name),
    imgUrl: data.sprites.front_default,
    height: data.height,
    weight: data.weight,
    experience: data.base_experience,
    abilities: formatAbilities(data.abilities),
  };
  console.log('RENDER - isModalOpen:', isModalOpen);
  return (
    <>
      <div
        onClick={() => setIsModalOpen(true)}
        className="bg-white dark:bg-neutral-800 w-[300px] rounded-2xl border border-gray-200 shadow-lg p-4 transition-transform hover:scale-105 cursor-pointer flex flex-col items-center relative"
      >
        <img
          src={pokemonData.imgUrl}
          alt={pokemonData.name}
          className="w-24 object-contain"
        />
        <h2 className="text-3xl font-bold mb-2">{pokemonData.name}</h2>
        <p>{pokemonData.id}</p>

        <PokemonFeatures
          height={pokemonData.height}
          weight={pokemonData.weight}
          experience={pokemonData.experience}
          ability={pokemonData.abilities}
        />

        {userLoggedIn && (
          <div className="absolute top-0 left-0 rounded-tl-2xl rounded-br-2xl bg-neutral-800 dark:bg-neutral-400 text-neutral-200 dark:text-neutral-800 py-2 px-4 font-semibold">
            <p>
              W: <span>1</span>
            </p>
            <p>
              L: <span>0</span>
            </p>
          </div>
        )}
      </div>

      {/* Pokemon Modal */}
      {isModalOpen && (
        <PokemonModal
          isOpen={isModalOpen}
          handleCloseModal={() => setIsModalOpen(false)}
          {...pokemonData}
        />
      )}
    </>
  );
};

export default PokemonCard;
