import React, { useContext } from 'react';
import Modal from './Modal';
import PokemonFeatures from './PokemonFeatures';
import { LoginContext } from '../../context/LoginContext';
import { RiHeartFill } from '@remixicon/react';
import { useFavourites } from '../../hooks/useFavourites';

const PokemonModal = ({
  isOpen,
  handleCloseModal,
  id,
  name,
  imgUrl,
  height,
  weight,
  experience,
  abilities,
}) => {
  const { userLoggedIn } = useContext(LoginContext);
  const { addFavourite, removeFavourite, isFavourite } = useFavourites();

  const handleFavouriteClick = () => {
    const pokemon = { id, name, imgUrl, height, weight, experience, abilities };
    if (isFavourite(id)) {
      removeFavourite(id);
    } else {
      addFavourite(pokemon);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={handleCloseModal}>
      <div className="p-3 flex flex-col sm:flex-row items-center">
        <img src={imgUrl} alt={name} className="w-24 object-contain" />
        <div className="flex flex-col items-center">
          <h2 className="text-2xl font-bold">{name}</h2>
          <PokemonFeatures
            height={height}
            weight={weight}
            experience={experience}
            ability={abilities}
          />
        </div>
      </div>
      {userLoggedIn && (
        <div className="absolute top-2 left-2 flex gap-1">
          <RiHeartFill
            size={28} // set custom `width` and `height`
            color={isFavourite(id) ? 'red' : 'white'} // set `fill` color
            stroke="black"
            className="cursor-pointer" // add custom class name
            onClick={handleFavouriteClick}
          />

          <span>(0/2)</span>
        </div>
      )}

      <button
        onClick={handleCloseModal}
        className="absolute top-1.5 right-1.5 cursor-pointer"
      >
        ❌
      </button>
    </Modal>
  );
};

export default PokemonModal;
