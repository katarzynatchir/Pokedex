import { createContext, useEffect, useState } from 'react';

export const ThemeContext = createContext(null);

export const ThemeProvider = ({ children }) => {
  const [darkMode, setDarkMode] = useState(() => {
    const savedValue = localStorage.getItem('darkTheme');
    return savedValue === 'true';
  });

  //Tailwind: How you add the dark class to the html element is up to you, but a common approach is to use a bit of JavaScript that updates the class attribute and syncs that preference to somewhere like localStorage.
  // html = document.documentElement
  useEffect(() => {
    const root = document.documentElement;

    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    //to już niepotrzebne:
    // const root = document.documentElement;
    // if (darkMode) {
    //   root.classList.remove('dark');
    // } else {
    //   root.classList.add('dark');
    // }

    setDarkMode(!darkMode);

    localStorage.setItem('darkTheme', !darkMode);
  };

  return (
    <ThemeContext.Provider value={{ darkMode, toggleDarkMode }}>
      {children}
    </ThemeContext.Provider>
  );
};
