import { useState, useEffect } from 'react';
const API_URL = 'http://localhost:3000/favourites';

export const useFavourites = () => {
  const [favourites, setFavourites] = useState([]);

  //pobieramy pokemony z bazy danych
  //nie mogę tego władować od razu do useEffect, bo będę tej funkcji jeszcze potrzebować, a w useEffect byłaby uwięziona i musiałabym pisać ją jeszcze raz
  const fetchFavourites = async () => {
    try {
      const res = await fetch(API_URL);
      const data = await res.json();
      setFavourites(data);
    } catch (error) {
      console.error(('Błąd podczas pobierania ulubionych:', error));
    }
  };

  //dodajemy pokemona do ulubionych
  const addFavourite = async pokemon => {
    try {
      const res = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pokemon),
      });
      console.log('res dodajemy pokemon:', res);
      setFavourites(prev => [...prev, pokemon]);
    } catch (error) {
      console.error('Błąd podczas dodawania do ulubionych:', error);
    }
  };

  //usuwamy pokemona z ulubionych
  const removeFavourite = async id => {
    try {
      await fetch(`${API_URL}/${id}`, {
        method: 'DELETE',
      });
      setFavourites(prev => prev.filter(fav => fav.id !== id));
    } catch (error) {
      console.error('Błąd podczas usuwania z ulubionych:', error);
    }
  };

  const isFavourite = id => {
    return favourites.some(fav => fav.id === id);
    //true jeśli pokemon jest w ulubionych
    //false jeśli pokemona nie ma w ulubionych
  };

  useEffect(() => {
    fetchFavourites();
  }, []);

  return { favourites, addFavourite, removeFavourite, isFavourite };
};
